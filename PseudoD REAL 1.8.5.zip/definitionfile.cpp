/*
**PseudoD 1.5.0
**Creado por Alejandro Linarez Rangel
*/
/* TODO: seguir reglas de LEEME:txt */
/*
	TODO:Simbolos predefinidos en este archivo:PDDATA,PDS,eas,buscar.
	TODO:Tipos predefinidos en esta cabecera: Los mismos que en includefilelib y inludefile.
*/
#include "NEA/Tipos.cpp"
#include "NEA/BibliotecaDinamica.cpp"
