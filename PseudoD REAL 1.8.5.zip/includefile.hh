/*
**PseudoD 1.5.0
**Creado por Alejandro Linarez Rangel
*/
/* TODO:seguir reglas de LEEME.txt */
/*
	TODO:Variables globales en esta cabecera:NINGUNA
	TODO:Tipos PRE-definidos en esta cabecera: string,ostream,istream,vector,stack,PDDatos.
	
*/
#include "NEA/Tipos.hh"
#include "NEA/BibliotecaDinamica.h"
