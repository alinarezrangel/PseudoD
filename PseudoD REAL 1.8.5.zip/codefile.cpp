/*
**PseudoD 1.5.0
**Creado por Alejandro Linarez Rangel
*/
/*if(o == PDS(""))
{

	
}
else if(o == PDS(""))
{
	*/
	/* TODO: seguir reglas de LEEME.txt */
/*
	TODO:TODOS los simbolos definidos en este archivo son los de includefile,includefilelib,definefile juntos.
*/
#include "NEA/PDTipos.cpp"
#include "NEA/PDBibliotecaDinamica.cpp"
