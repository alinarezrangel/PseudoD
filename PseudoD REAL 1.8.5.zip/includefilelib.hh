/*
**PseudoD 1.5.0
**Creado por Alejandro Linarez Rangel
*/
/*
	TODO: Esta cabecera SOLO debe incluir BIBLIOTECAS estandares, y que no necesiten SIMBOLOS especiales de COMPILACION.
*/
/*
#include <iostream>
	#include <fstream>
	#include <cstdlib>
	#include <vector>
	#include <stack>
	#include <string>
	#include <cstring>
	#include <cstdio>
TODO TODO :YA SE INCLUYERON
*/
#include "NEA/INBibliotecaDinamica.h"
#include <sstream>
