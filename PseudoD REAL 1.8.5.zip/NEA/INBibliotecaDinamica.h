/*
**PseudoD 1.5.0
**Creado por Alejandro Linarez Rangel
*/
#include <dlfcn.h>
