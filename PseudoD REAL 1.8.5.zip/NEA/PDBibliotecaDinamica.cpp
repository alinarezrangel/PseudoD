/*
**PseudoD 1.5.0
**Creado por Alejandro Linarez Rangel
*/
{
	BibliotecaDinamica::PseudoLlamar l;
	if(o == PDS(l.ObtenerClave()))
	{
		l.LeerParametros(i);
		l.InscribirInstancia(PDDATA);
	}
}
